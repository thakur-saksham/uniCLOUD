/* take inked list as user inpu then print it then take user input of data find nth position in linked list linked list*/
#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* next;
};
struct Node* head,*newnode,*temp;
void findNthPosition(int n) {
    temp = head;
    int count = 1;
    while (temp != NULL) {
        if (count == n) {
            printf("Data at position %d: %d\n", n, temp->data);
            return;
        }
        count++;
        temp = temp->next;  
    }
    printf("Position %d does not exist in the linked list.\n", n);
}
void printList() {
    temp = head;
    printf("Linked List: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}
int main() {
    int n, position;
    head = NULL;
    printf("Enter the number of nodes: ");
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        newnode = (struct Node*)malloc(sizeof(struct Node));
        printf("Enter data for node %d: ", i + 1);
        scanf("%d", &newnode->data);
        newnode->next = NULL;
        if (head == NULL) {
            head = newnode;
            temp = head;
        } else {
            temp->next = newnode;
            temp = temp->next;
        }
    }
    printList();
    printf("Enter the position to find: ");
    scanf("%d", &position);
    findNthPosition(position);
    return 0;
}
