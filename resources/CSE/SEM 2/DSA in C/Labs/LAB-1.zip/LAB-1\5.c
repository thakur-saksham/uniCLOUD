/*5 Find the product of two matrices using pointers and take user input small code.*/
#include <stdio.h>
void multiplyMatrices(int first[][10], int second[][10], int result[][10], int
    rows1, int cols1, int cols2) {
        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < cols2; j++) {
                result[i][j] = 0;
                for (int k = 0; k < cols1; k++) {
                    result[i][j] += first[i][k] * second[k][j];
                }
            }
        }
    }
int main() {
    int first[10][10], second[10][10], result[10][10];
    int rows1, cols1, rows2, cols2;
    printf("Enter rows and columns for first matrix: ");
    scanf("%d %d", &rows1, &cols1);
    printf("Enter rows and columns for second matrix: ");
    scanf("%d %d", &rows2, &cols2);
    if (cols1 != rows2) {
        printf("Incompatible matrix dimensions\n");
        return 1;
    }
    printf("Enter elements of first matrix:\n");
    for (int i = 0; i < rows1; i++) {
        for (int j = 0; j < cols1; j++) {
            scanf("%d", &first[i][j]);
        }
    }
    printf("Enter elements of second matrix:\n");
    for (int i = 0; i < rows2; i++) {
        for (int j = 0; j < cols2; j++) {
            scanf("%d", &second[i][j]);
        }
    }   
    multiplyMatrices(first, second, result, rows1, cols1, cols2);
    printf("Product of the matrices:\n");
    for (int i = 0; i < rows1; i++) {
        for (int j = 0; j < cols2; j++) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }
    return 0;
}
