#include <stdio.h>

int arra(int arr[], int n) {
    if (n <= 0)
        return 0;
    return arr[n - 1] + arra(arr, n - 1);
}

int main() {
    int arr[100], n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter array elements:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int sum = arra(arr, n);
    printf("Sum of array elements: %d\n", sum);

    return 0;
}
