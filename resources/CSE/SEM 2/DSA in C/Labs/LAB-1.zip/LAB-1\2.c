/*2 Create an array ‘a1’ with ‘n’ elements from user. Insert an element in ith position of ‘a1’ and also delete an
element from jth position of ‘a1’. easy code.take array as user input and aks ehat to delet and what to not*/
#include <stdio.h>
void insertElement(int arr[], int *n, int element, int position) {
    for (int i = *n; i > position; i--) {
        arr[i] = arr[i - 1];
    }
    arr[position] = element;
    (*n)++;
}
void deleteElement(int arr[], int *n, int position) {
    for (int i = position; i < *n - 1; i++) {
        arr[i] = arr[i + 1];
    }
    (*n)--;
}
int main() {
    int arr[100], n;
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);
    printf("Enter the elements of the array: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    int element, position;
    printf("Enter the element to insert: ");
    scanf("%d", &element);
    printf("Enter the position to insert the element (0-based index): ");
    scanf("%d", &position);
    insertElement(arr, &n, element, position);
    printf("Array after insertion: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    int deletePosition;
    printf("Enter the position to delete an element (0-based index): ");
    scanf("%d", &deletePosition);
    deleteElement(arr, &n, deletePosition   );
    printf("Array after deletion: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}

