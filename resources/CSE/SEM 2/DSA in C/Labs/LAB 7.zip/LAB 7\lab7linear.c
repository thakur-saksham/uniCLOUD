#include <stdio.h>
#define SIZE 10

int table[SIZE];

void init() {
    for(int i = 0; i < SIZE; i++) table[i] = -1;
}

int hash(int key) {
    return key % SIZE;
}

void insert(int key) {
    int index = hash(key);
    int start = index;

    while(table[index] != -1) {
        index = (index + 1) % SIZE;
        if(index == start) {
            printf("Table Full\n");
            return;
        }
    }
    table[index] = key;
}

int search(int key) {
    int index = hash(key);
    int start = index;

    while(table[index] != -1) {
        if(table[index] == key) return index;
        index = (index + 1) % SIZE;
        if(index == start) break;
    }
    return -1;
}

void delete(int key) {
    int pos = search(key);
    if(pos != -1) table[pos] = -1;
}

void display() {
    for(int i = 0; i < SIZE; i++)
        printf("%d -> %d\n", i, table[i]);
}