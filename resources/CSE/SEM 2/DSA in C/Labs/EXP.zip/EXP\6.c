/*Question 6: Linear search in array
Your understanding of the problem

Search for a given element in an array using linear search.

Algorithm

Read array elements

Read key element

Compare each element sequentially

Display result*/


#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    double a[n];

    for(int i = 0; i < n; i++)
        scanf("%lf", &a[i]);

    for(int i = 0; i < n; i++)
        printf("%.2lf ", a[i]);

    return 0;
}
