/*Question 3: Convert uppercase string to lowercase
Your understanding of the problem

Convert all uppercase letters in a string to lowercase using a for loop.

Algorithm

Read string

Check each character

If uppercase, convert to lowercase

Print result*/

#include <stdio.h>

int main()
{
    char s[100];
    scanf("%s", s);

    for(int i = 0; s[i] != '\0'; i++)
        if(s[i] >= 'A' && s[i] <= 'Z')
            s[i] = s[i] + 32;

    printf("%s\n", s);
    return 0;
}
