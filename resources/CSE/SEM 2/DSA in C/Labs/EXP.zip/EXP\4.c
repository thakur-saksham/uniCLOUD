/*Question 4: Sum of rows and columns of a matrix
Your understanding of the problem

Calculate row-wise and column-wise sums of a matrix.

Algorithm

Read matrix order

Read elements

Calculate sum of each row

Calculate sum of each column*/


#include <stdio.h>

int main()
{
    int r, c;
    scanf("%d %d", &r, &c);
    int a[r][c];

    for(int i = 0; i < r; i++)
        for(int j = 0; j < c; j++)
            scanf("%d", &a[i][j]);

    for(int i = 0; i < r; i++)
    {
        int rs = 0;
        for(int j = 0; j < c; j++)
            rs += a[i][j];
        printf("%d\n", rs);
    }

    for(int j = 0; j < c; j++)
    {
        int cs = 0;
        for(int i = 0; i < r; i++)
            cs += a[i][j];
        printf("%d\n", cs);
    }

    return 0;
}
