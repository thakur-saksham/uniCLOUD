/*Question 2: Insert and delete element in array
Your understanding of the problem

Create an array, insert an element at a given position, and delete an element from another position.

Solution discussed in the group

Shift elements right for insertion and left for deletion.


Algorithm

Read array size and elements

Insert element at ith position

Delete element from jth position

Display updated array*/

#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    int a[100];
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    int pos, val;
    scanf("%d %d", &pos, &val);

    for(int i = n; i > pos; i--)
        a[i] = a[i - 1];
    a[pos] = val;
    n++;

    int del;
    scanf("%d", &del);
    for(int i = del; i < n - 1; i++)
        a[i] = a[i + 1];
    n--;

    for(int i = 0; i < n; i++)
        printf("%d ", a[i]);

    return 0;
}
