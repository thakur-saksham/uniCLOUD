/*Question 1: Sum of all array elements using recursion
Your understanding of the problem

We need to calculate the sum of all elements in an array by calling a recursive function that adds one element at a time.

Solution discussed in the group

Use a recursive function where:

Base case: if size is 0, return 0

Recursive case: return last element + sum of remaining elements

Algorithm

Read number of elements n

Read array elements

Call recursive function sum(arr, n)

Print the returned sum*/

#include <stdio.h>

int sum(int a[], int i)
{
    if(i < 0)
        return 0;
    return a[i] + sum(a, i - 1);
}

int main()
{
    int n;
    scanf("%d", &n);
    int a[n];
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("%d\n", sum(a, n - 1));
    return 0;
}
