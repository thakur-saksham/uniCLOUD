#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char input[200];
    printf("Enter a string: ");
    fgets(input, 200, stdin);
    input[strcspn(input, "\n")] = 0;  //ye \n ki position find krega and will replace with \0

    int len = strlen(input);  //string length find krege
    
    char *stack = (char *)malloc(len * sizeof(char));
    int top = -1;

    for (int i = 0; i < len; i++) {
        stack[++top] = input[i];     //first increment the stack and then insert 
    }

    for (int i = 0; i < len; i++) {
        input[i] = stack[top--];  //it iwll takee from the top(jo last inserted hoga) and decrease  the top indez
    }

    printf("Reversed String: %s\n", input);

    free(stack);
    return 0;
}

