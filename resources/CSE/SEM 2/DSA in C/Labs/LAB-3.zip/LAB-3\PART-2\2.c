#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *queue;
int front = -1, rear = -1;

void enqueue(char c) {
    if (front == -1) front = 0;
    queue[++rear] = c;
}

char dequeue() {
    return queue[front++];
}

int main() {
    char str[100];
    printf("Enter a string: ");
    scanf("%s", str);

    int len = strlen(str);
    queue = (char *)malloc(len * sizeof(char));

    for (int i = 0; i < len; i++) {
        enqueue(str[i]);
    }

    int isPalindrome = 1;
    for (int i = len - 1; i >= 0; i--) {
        if (str[i] != dequeue()) {
            isPalindrome = 0;
            break;
        }
    }

    if (isPalindrome) printf("The string is a palindrome.\n");
    else printf("The string is NOT a palindrome.\n");

    free(queue);
    return 0;
}

