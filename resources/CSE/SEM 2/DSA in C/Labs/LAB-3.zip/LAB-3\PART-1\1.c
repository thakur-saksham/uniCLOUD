#include <stdio.h>
#include <stdlib.h>

int *stack;
int top = -1, MAX;

void push() {
    if (top == MAX - 1) {
        printf("[!] Overflow! Stack is full.\n");
    } else {
        int val;
        printf("Enter value to push: ");
        scanf("%d", &val);
        stack[++top] = val;
        printf("[+] Pushed %d\n", val);
    }
}

void pop() {
    if (top == -1) {
        printf("[!] Underflow! Stack is empty.\n");
    } else {
        printf("[-] Popped: %d\n", stack[top--]);
    }
}

void display() {
    if (top == -1) {
        printf("[i] Stack is empty.\n");
    } else {
        printf("Stack: ");
        for (int i = top; i >= 0; i--) printf("%d ", stack[i]);
        printf("\n");
    }
}

int main() {
    printf("Enter the size of the stack: ");
    scanf("%d", &MAX);

    stack = (int *)malloc(MAX * sizeof(int));

    int choice;
    while (1) {
        printf("\n1. Push | 2. Pop | 3. Display | 4. Exit\nChoice: ");
        scanf("%d", &choice);
        if (choice == 1) push();
        else if (choice == 2) pop();
        else if (choice == 3) display();
        else if (choice == 4) break;
        else printf("Invalid!\n");
    }

    free(stack); 
    return 0;
}
