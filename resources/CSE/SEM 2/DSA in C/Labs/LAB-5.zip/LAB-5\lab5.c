#include <stdio.h>
#include <stdlib.h>

// Node structure
struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

// Create a new node
struct Node* createNode(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

// Build tree using user input
struct Node* buildTree() {
    int value;
    printf("Enter value (-1 for no node): ");
    scanf("%d", &value);

    if (value == -1) {
        return NULL;
    }

    struct Node* root = createNode(value);

    printf("Enter left child of %d:\n", value);
    root->left = buildTree();

    printf("Enter right child of %d:\n", value);
    root->right = buildTree();

    return root;
}

// Pre-order traversal
void preOrder(struct Node* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preOrder(root->left);
        preOrder(root->right);
    }
}

// In-order traversal
void inOrder(struct Node* root) {
    if (root != NULL) {
        inOrder(root->left);
        printf("%d ", root->data);
        inOrder(root->right);
    }
}

// Post-order traversal
void postOrder(struct Node* root) {
    if (root != NULL) {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d ", root->data);
    }
}

int main() {
    printf("Build the Binary Tree:\n");
    struct Node* root = buildTree();

    printf("\nPre-order Traversal: ");
    preOrder(root);

    printf("\nIn-order Traversal: ");
    inOrder(root);

    printf("\nPost-order Traversal: ");
    postOrder(root);

    return 0;
}