#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int queue[MAX], front = -1, rear = -1;
int stack[MAX], top = -1;

void enqueue(int val) {
    if (rear == MAX - 1) return;
    if (front == -1) front = 0;
    queue[++rear] = val;
}

int dequeue() {
    if (front == -1 || front > rear) return -1;
    return queue[front++];
}

void push(int val) {
    stack[++top] = val;
}

int pop() {
    return stack[top--];
}

void reverseK(int n, int k) {
    for (int i = 0; i < k; i++) {
        push(dequeue());
    }

    while (top != -1) {
        enqueue(pop());
    }

    for (int i = 0; i < (n - k); i++) {
        enqueue(dequeue());
    }
}

void display(int n) {
    for (int i = front; i <= rear; i++) {
        printf("%d ", queue[i]);
    }
    printf("\n");
}

int main() {
    int n, k, val;

    printf("Enter number of people (N): ");
    scanf("%d", &n);
    printf("Enter ticket numbers: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &val);
        enqueue(val);
    }
    printf("Enter K: ");
    scanf("%d", &k);

    if (k > n || k <= 0) {
        printf("Invalid K\n");
    } else {
        reverseK(n, k);
        printf("Rearranged Line: ");
        display(n);
    }

    return 0;
}


//Phase 1: Move $k$ elements to a StackDequeue the first $k$ elements from the front of the queue one by one.Push each of these $k$ elements onto a stack.Result: The stack now contains the first $k$ elements, but because it's a stack, the $k$-th element is now at the top.
//hase 2: Transfer Stack back to QueuePop all elements from the stack.Enqueue each popped element back into the rear of the queue.Result: The first $k$ elements are now at the very back of the queue in reversed order. The original elements from $(k+1)$ to $n$ are now at the front.
//Phase 3: Rotate the remaining $(n - k)$ elementsDequeue the remaining $(n - k)$ elements (the ones that were originally at the back) from the front of the queue.Enqueue each of these elements immediately back into the rear of the queue.Result: This "rotates" the queue so that the reversed $k$ elements move from the back to the front, and the remaining elements follow them in their original order.