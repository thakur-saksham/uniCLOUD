#include <stdio.h>
#include <ctype.h>
#include <string.h>

char stack[100];
int top = -1;

void push(char x) {
    stack[++top] = x;
}

char pop() {
    if (top == -1) return -1;
    return stack[top--];
}

int priority(char x) {
    if (x == '(') return 0;
    if (x == '+' || x == '-') return 1;
    if (x == '*' || x == '/') return 2;
    return 0;
}

void infixToPostfix(char* infix, char* postfix) {
    int k = 0;
    char x;
    for (int i = 0; infix[i] != '\0'; i++) {
        if (isalnum(infix[i])) {
            postfix[k++] = infix[i];
        } else if (infix[i] == '(') {
            push('(');
        } else if (infix[i] == ')') {
            while ((x = pop()) != '(')
                postfix[k++] = x;
        } else {
            while (top != -1 && priority(stack[top]) >= priority(infix[i]))
                postfix[k++] = pop();
            push(infix[i]);
        }
    }
    while (top != -1)
        postfix[k++] = pop();
    postfix[k] = '\0';
}

int evalStack[100];
int eTop = -1;

void pushEval(int x) {
    evalStack[++eTop] = x;
}

int popEval() {
    return evalStack[eTop--];
}

int evaluate(char* postfix) {
    for (int i = 0; postfix[i] != '\0'; i++) {
        if (isdigit(postfix[i])) {
            pushEval(postfix[i] - '0');
        } else {
            int v1 = popEval();
            int v2 = popEval();
            switch (postfix[i]) {
                case '+': pushEval(v2 + v1); break;
                case '-': pushEval(v2 - v1); break;
                case '*': pushEval(v2 * v1); break;
                case '/': pushEval(v2 / v1); break;
            }
        }
    }
    return popEval();
}

int main() {
    char infix[100], postfix[100];

    printf("Enter infix expression: ");
    scanf("%s", infix);

    infixToPostfix(infix, postfix);
    
    printf("Postfix: %s\n", postfix);
    printf("Result: %d\n", evaluate(postfix));

    return 0;
}