#include <stdio.h>
#include <ctype.h>
#include <math.h>

int stack[100];
int top = -1;

void push(int x) {
    stack[++top] = x;
}

int pop() {
    return stack[top--];
}

int evaluatePostfix(char* exp) {
    for (int i = 0; exp[i] != '\0'; i++) {
        
        if (isdigit(exp[i])) {
            push(exp[i] - '0');
        } 
        else {
            int val1 = pop();
            int val2 = pop();
            
            switch (exp[i]) {
                case '+': push(val2 + val1); break;
                case '-': push(val2 - val1); break;
                case '*': push(val2 * val1); break;
                case '/': push(val2 / val1); break;
                case '^': push(pow(val2, val1)); break;
            }
        }
    }
    return pop();
}

int main() {
    char exp[100];
    printf("Enter postfix expression: ");
    scanf("%s", exp);
    
    printf("Result of evaluation: %d\n", evaluatePostfix(exp));
    return 0;
}