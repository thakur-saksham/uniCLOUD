

    printf("Enter number of people (N): ");
    scanf("%d", &n);
    printf("Enter ticket numbers: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &val);
        enqueue(val);
    }